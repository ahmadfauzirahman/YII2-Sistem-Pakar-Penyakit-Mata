<?php
    /**
     * Created by PhpStorm.
     * User: asrory
     * Date: 21/12/16
     * Time: 6:16
     */
header("location:web/");