<?php
    /**
     * Created by PhpStorm.
     * User: asrory
     * Date: 18/01/17
     * Time: 20:58
     */
    use app\models\Gejala;
    use app\models\Penyakit;
    use yii\helpers\ArrayHelper;
    use yii\helpers\Html;
    use yii\widgets\ActiveForm;

?>
<?php
    //    $jumlahData = count($model->getRecords());
    $lengthCtrl = function($model , $rules_ke){
        $jika = $model->getRecord($rules_ke , $model->getRecords());
        $control = $model->getControlIf($jika["jika"]);

        return $control;
    };
http://localhost/es/web/index.php?r=rules%2Fkonsultasi&rules_ke=0&pertanyaan_ke=2
    $pertanyaan = function($model , $pertanyaan_ke , $control,$rules_ke,$result=null){
        $html = "<center><div class=\"panel panel-default\">
        <div class=\"panel-heading\">
            <h3 class=\"panel-title\">Pertanyaan : ".$model->getAskByKey($control[ $pertanyaan_ke ])."</h3></div>
        <div class=\"panel-body\">
            <a class='btn btn-success' href='?r=rules/konsultasi&rules_ke=".$rules_ke."&pertanyaan_ke=".($pertanyaan_ke+1)."&result=".((isset($result)&&($result!=null))?$result."+".$control[ $pertanyaan_ke ]:$control[ $pertanyaan_ke ])."'>Ya</a>&nbsp<a class='btn btn-danger' href=''>Tidak</a>
        </div>
    </div></center>";
        return $html;
    };
    //    $jumlahCtrl = count($control);
    $control = $lengthCtrl($model , $_GET["rules_ke"]);
    $tanya = $pertanyaan($model , $_GET["pertanyaan_ke"] , $control, $_GET["rules_ke"],(isset($_GET["result"])?$_GET["result"]:null));
?>

<?php $form = ActiveForm::begin();
    echo $tanya;
?>

<?php ActiveForm::end(); ?>
