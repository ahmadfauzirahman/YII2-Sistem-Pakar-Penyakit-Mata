<?php
    /**
     * Created by
     * User: asrory
     * Date: 19/01/17
     * Time: 10:43
     */
?>
<script>alert('Maaf.. Penyakit dengan gejala yang anda maksud tidak ditemukan');
    window.location.href = 'index.php';
</script>";