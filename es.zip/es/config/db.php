<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=sp_mata',
    'username' => 'root',
    'password' => 'enteraja',
    'charset' => 'utf8',
];
